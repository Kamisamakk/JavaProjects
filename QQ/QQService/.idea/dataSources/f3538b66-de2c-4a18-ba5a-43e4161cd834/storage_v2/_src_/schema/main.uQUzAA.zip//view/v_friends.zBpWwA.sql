CREATE VIEW v_friends as
select a.user_id,a.password,a.user_name,a.user_sex,friendsList_name,friend_id,b.password friend_pwd, b.user_name friend_name, b.user_sex friend_sex from 
(select user_id,password,user_name,user_sex,friendsList_name,friend_id from 
(select a.user_id,password,user_name,user_sex,id,friendsList_name from tbl_user a left join friendsList b on a.user_id=b.user_id)
 a left join friends b on a.id = b.friendsList_id) 
 a left join tbl_user b on a.friend_id=b.user_id;

