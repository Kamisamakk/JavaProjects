CREATE VIEW view_stu as select a.id,stu_name,sub_name,sco_score,class_name from (select id,stu_name,sub_name,sco_score,stu_classid from (select sco_stuid,sub_name,sco_score from tbl_score a left join tbl_subject b on a.sco_subid=b.sub_id) as a left join tbl_student as b on a.sco_stuid=b.id) as a left join tbl_class as b on a.stu_classid = b.id where sco_score >= 60 order by sco_score desc;

